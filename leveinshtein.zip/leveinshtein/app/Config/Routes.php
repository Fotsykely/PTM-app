<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Recherche::index'); // Redirige vers la page de recherche
$routes->get('recherche', 'Recherche::index');
$routes->get('recherche/chercher', 'Recherche::chercher');
