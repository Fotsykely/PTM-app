<?php

namespace App\Controllers;

use App\Models\MotModel;

class Recherche extends BaseController
{
    public function index()
    {
        return view('recherche');
    }

    public function chercher()
    {
        $mot = $this->request->getVar('mot');
        $model = new MotModel();

        if ($mot) {
            $resultats = $model->rechercherMotsSimilaires($mot);
            return json_encode($resultats);
        }

        return json_encode([]);
    }
}
