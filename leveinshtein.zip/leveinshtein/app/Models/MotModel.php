<?php

namespace App\Models;

use CodeIgniter\Model;

class MotModel extends Model
{
    protected $table = 'mots';
    protected $primaryKey = 'id';
    protected $allowedFields = ['mot'];

    public function rechercherMotsSimilaires($terme)
{
    $mots = $this->findAll();
    $resultats = [];

    foreach ($mots as $mot) {
        // Vérifie si le mot contient le terme de recherche
        if (stripos($mot['mot'], $terme) !== false) {
            $resultats[$mot['mot']] = levenshtein($terme, $mot['mot']);
        }
    }

    asort($resultats);
    return array_keys(array_slice($resultats, 0, 4, true));
}
}
