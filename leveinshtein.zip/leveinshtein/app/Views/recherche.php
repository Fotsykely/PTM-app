<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recherche de Mots</title>
    <style>
        body { font-family: Arial, sans-serif; }
        #resultats { margin-top: 10px; }
        .mot { margin: 5px 0; }
    </style>
</head>
<body>
    <h1>Recherche de Mots</h1>
    <input type="text" id="recherche" placeholder="Tapez un mot..." />
    <div id="resultats"></div> <!-- Suggestions sous la barre de recherche -->

    <script>
        document.getElementById('recherche').addEventListener('input', function() {
            let terme = this.value;

            if (terme.length > 0) {
                fetch('<?= site_url('recherche/chercher') ?>?mot=' + terme)
                    .then(response => response.json())
                    .then(data => {
                        const resultatsDiv = document.getElementById('resultats');
                        resultatsDiv.innerHTML = '';
                        data.forEach(mot => {
                            const div = document.createElement('div');
                            div.classList.add('mot');
                            div.textContent = mot;
                            resultatsDiv.appendChild(div);
                        });
                    });
            } else {
                document.getElementById('resultats').innerHTML = '';
            }
        });
    </script>
</body>
</html>
